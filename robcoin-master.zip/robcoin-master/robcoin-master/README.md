SHITCOIN BITCHES!

500,000,000 per block reward, halving every 2000 blocks.

Minimum block reward 1,000,000 coins.

Maximum of 100,000,000,000,000 ever coins.

.0001% stake after 69 days

RPC/P2P Ports = 8505/8506